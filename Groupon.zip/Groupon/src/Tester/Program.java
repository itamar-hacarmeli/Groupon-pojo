package Tester;

import DB.DatabaseManager;
import Exceptions.UserErrorException;

import java.sql.SQLException;


public class Program {
    public static void main(String[] args) throws SQLException, InterruptedException, UserErrorException {
      Test.testAll();


    }
}















