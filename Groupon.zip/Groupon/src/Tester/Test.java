package Tester;


import Beans.Category;
import Beans.Company;
import Beans.Coupon;
import Beans.Customer;
import DAO.CompaniesDAO;
import DAO.CouponsDAO;
import DAO.CustomersDAO;
import DB.ConnectionPool;
import DB.DatabaseManager;
import DBDAO.CompaniesDBDAO;
import DBDAO.CouponsDBDAO;
import DBDAO.CustomersDBDAO;
import Exceptions.UserErrorException;
import Facades.AdminFacade;
import Facades.CompanyFacade;
import Facades.CustomerFacade;
import LoginManager.LoginManager;
import LoginManager.ClientType;
import Threads.CouponExpirationDailyJob;

import java.sql.SQLException;

public class Test {
    public static void testAll() {
        CouponsDAO couponsDAO = new CouponsDBDAO();
        CompaniesDAO companiesDAO = new CompaniesDBDAO();
        CustomersDAO customersDAO = new CustomersDBDAO();

        try {
            DatabaseManager.createDBWithContent();
            //CouponExpirationDailyJob dailyJob = new CouponExpirationDailyJob();
            //Thread thread = new Thread(dailyJob);
            //thread.start();
            //dailyJob.stop();


            AdminFacade adminFacade = (AdminFacade) LoginManager.getInstance().login("admin@admin.com", "admin", ClientType.ADMINISTRATOR);

            Company company = new Company("Samsung", "Samsung@gmail.com", "4321");
            //adminFacade.addCompany(company);
            //System.out.println("Was the company successfully added ?\n" + companiesDAO.doesCompanyExist(company.getName(), company.getEmail()));

            //Add Company - Failed - Name already exists
            Company company1 = new Company("Microsoft", "david@gmail.com®", "1111");
            //adminFacade.addCompany(company1);

            // Add Company - Failed - Email already exists
            Company company2 = new Company("Nike", "apple@gmail.com", "6565");
            // adminFacade.addCompany(company2);


            Company companyForUpdate = new Company(6, "Samsung", "Samsung@gmail.com", "4444");
            //adminFacade.updateCompany(companyForUpdate);

            //Update Company - Failed - Cannot update Company Id
            Company company5 = new Company(7, "Samsung", "Samsung@gmail.com", "4444");
            //adminFacade.updateCompany(company5);
            //System.out.println("Does company exist ?\n"+companiesDAO.doesCompanyExistByID(company5.getId()));

            //Update Company - Failed - Cannot update Company Name
            Company company4 = new Company(6, "Nokia", "Samsung@gmail.com", "4444");
            //adminFacade.updateCompany(company4);
            // System.out.println("Does company exist ?\n"+companiesDAO.doesCompanyExistByName(company4));

            Company companyForDelete = new Company(4, "John bryce", "jb@gmail.com", "1594");
            //adminFacade.deleteCompany(companyForDelete.getId());
            //System.out.println(companiesDAO.doesCompanyExist(companyForDelete.getName(), companyForDelete.getEmail()) == true ?
            //"The company was not deleted" : "The company was successfully deleted");

            //adminFacade.getAllCompanies();

            Company company3 = new Company("Amazon", "amazon@gmail.com", "7777");
            //adminFacade.getOneCompany(5);

            Customer customer1 = new Customer("Ronny", "Levy", "ronny@gmail.com", "1234");
            //adminFacade.addCustomer(customer1);
            //System.out.println("Was the customer successfully added ?\n" + customersDAO.doesCustomerExist(customer1.getEmail()));


            //Add Customer - Failed - Email already exists
            Customer customer = new Customer("Shimon", "Ben", "tom@gmail.com", "3444");
            //adminFacade.addCustomer(customer);

            Customer customerForUpdate = new Customer(3, "Tom", "Cohen", "yossi@gmail.com", "fgdf");
            // adminFacade.updateCustomer(customerForUpdate);

            //Update Customer - Failed - Cannot change id number
            Customer customer3 = new Customer(14, "Israel", "Israeli", "israel@gmail.com", "3444");
            //adminFacade.updateCustomer(customer3);

            Customer customerForDelete = new Customer(6, "Ron", "Alon", "ron@gmail.com", "k43yy");
            //adminFacade.deleteCustomer(6);
            //System.out.println(customersDAO.doesCustomerExistsByID(customerForDelete.getId()) == false ?
            //"Customer successfully deleted" : "Customer was not deleted");

            //  adminFacade.getAllCustomers();

            Customer customer2 = new Customer(4, "Avi", "Levi", "avi@gmail.com", "cvv");
            //adminFacade.getOneCustomer(4);


            //====================================================================

            //CustomerFacade customerFacade = (CustomerFacade) LoginManager.getInstance().login("avi@gmail.com", "cvv", ClientType.CUSTOMER);

            //customerFacade.purchaseCoupon(9);

            //customerFacade.getCustomerPurchasedCoupons();

            //customerFacade.getCustomerCouponsByCategory(Category.ELECTRICITY);
            //customerFacade.getCustomerCouponsByMaxPrice(100);
            //customerFacade.showCustomerDetails();

            //====================================================================

            //CompanyFacade companyFacade = (CompanyFacade) LoginManager.getInstance().login("apple@gmail.com", "3221", ClientType.COMPANY);

            Coupon coupon = new Coupon(1, Category.ELECTRICITY.getCategoryId(), "111", "111", couponsDAO.getDate(1955, 12, 31), couponsDAO.getDate(2023, 1, 1), 10, 22, "image");
            //companyFacade.addCoupon(coupon);
            //System.out.println("Was the coupon successfully added ?\n" + couponsDAO.doesCompanyCouponsExist(coupon));

            Coupon couponForUpdate = new Coupon(5, 2, 1, "1111", "1111", couponsDAO.getDate(2020, 4, 4), couponsDAO.getDate(2022, 8, 8), 40, 13.4, "image");
            //companyFacade.updateCoupon(couponForUpdate);

            //companyFacade.getCouponsByCompany(companyFacade.getCompanyID());

            //companyFacade.getCouponsByCompanyAndCategory(companyFacade.getCompanyID(), 1);
            //companyFacade.getCompanyCouponsByMaxPrice(companyFacade.getCompanyID(), 100);

            //companyFacade.deleteCoupon(7);
            //System.out.println("Is the coupon still in the database ?\n"+couponsDAO.doesCouponExist(7,2));

            //companyFacade.getCompanyDetails(companyFacade.getCompanyID());


            // ConnectionPool.getInstance().closeAllConnection();


        } catch (UserErrorException | SQLException err) {
            if (err instanceof UserErrorException) {
                System.out.println(err.getMessage());
            } else if (err instanceof SQLException) {
                System.out.println(err.getMessage());
            } else {
                System.out.println(err.getMessage());
            }
        } catch (Exception err) {
            System.out.println(err.getMessage());
        }

    }
}
