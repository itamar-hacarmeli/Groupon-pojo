package Facades;

import Beans.Category;
import Beans.Company;
import Beans.Coupon;
import Beans.Customer;
import DB.DBUtils;
import Exceptions.UserErrorException;

import java.sql.SQLException;
import java.sql.SQLOutput;
import java.util.InputMismatchException;
import java.util.List;

public class CompanyFacade extends ClientFacade {
    private int companyID;

    public int getCompanyID() {
        return companyID;
    }

    /**
     * A default constructor that is used in the "LoginManager" class, "login" method.
     * Creates a companyFacade object that allows the use of the method "login".
     */
    public CompanyFacade() {
    }

    /**
     * A full argument constructor.
     *
     * @param companyID - The id of the company
     */
    public CompanyFacade(int companyID){
        this.companyID = companyID;
    }

    /**
     * Checks if the email and password, that were typed by the user, matches the user's details
     * in the data base.
     *
     * @param email    - The company's email.
     * @param password - The company's password.
     * @return - A Company object.
     * @throws UserErrorException - Incorrect email or password typed by the user.
     * @throws SQLException       - Incorrect sql command.
     */
    public Company login(String email, String password) throws SQLException, UserErrorException {
        return companiesDAO.login(email, password);
    }

    /**
     * Receives a Coupon object from the user, checks if the coupon already exists in the
     * data base, and if it doesn't - adds it to the data base and to the company's
     * coupons list.
     *
     * @param coupon - A Coupon object. Given by the user.
     * @throws SQLException       - Incorrect sql command.
     * @throws UserErrorException - The coupon already exists in the data base.
     */
    public void addCoupon(Coupon coupon) throws SQLException, UserErrorException {
        boolean result = couponsDAO.doesCompanyCouponsExist(coupon);
        if (result) {
            throw new UserErrorException("'CouponsDBDAO'", "'doesCompanyCouponsExist'", "There is already a coupon with these details in the DB. The coupon was NOT added.");
        }
        couponsDAO.addCoupon(coupon);
    }


    /**
     * Receives a Coupon object from the user, checks if the coupon already exists in the
     * data base, and if it does - updates it by the coupon object.
     *
     * @param coupon - A coupon object. Given by the user.
     * @throws SQLException       - Incorrect sql command.
     * @throws UserErrorException - The coupon does not exist.
     */
    public void updateCoupon(Coupon coupon) throws SQLException, UserErrorException {
        boolean result = couponsDAO.doesCouponExist(coupon.getId(), coupon.getCompanyID());
        if (!result) {
            throw new UserErrorException("'CouponsDBDAO'", "'doesCouponExist'", "Coupon does not exist.");
        }
        couponsDAO.updateCoupon(coupon);
    }


    /**
     * Checks if a coupon exists in the data base (by id), and if it does - deletes it.
     *
     * @param couponID - The id of the coupon.
     * @throws SQLException       - Incorrect sql command.
     * @throws UserErrorException - The coupon does not exist in the data base.
     */
    public void deleteCoupon(int couponID) throws SQLException, UserErrorException {
        boolean result = couponsDAO.doesCouponExist(couponID, companyID);
        if (result) {
            couponsDAO.deleteCoupon(couponID);
        } else {
            throw new UserErrorException("'CouponDBDAO'", "'doesCouponExist'", "Coupon does not exist for this company. there is nothing to delete.");
        }
    }

    /**
     * Gets all the coupons of a specific company from the data base (by company id), puts them
     * into a list, and prints their details.
     *
     * @param companyID - The id of the company.
     * @return - A list of Coupon objects.
     * @throws SQLException - Incorrect sql command.
     */
    public List<Coupon> getCouponsByCompany(int companyID) throws SQLException {
        return couponsDAO.getCouponsByCompany(companyID);
    }

    /**
     * Gets all the coupons of a specific company and a specific category from the data base
     * (by company id and category id), puts them into a list, and prints their details.
     *
     * @param companyID - The id of the company.
     * @return - A list of Coupon objects.
     * @throws SQLException - Incorrect sql command.
     */
    public List<Coupon> getCouponsByCompanyAndCategory(int companyID, int categoryID) throws SQLException, UserErrorException {
        return couponsDAO.getCouponsByCompanyAndCategory(companyID, categoryID);
    }

    /**
     * Gets all the coupons of a specific company, under or equal to a given price, from the data
     * base. Then it puts them into a list, and prints their details.
     *
     * @param companyID - The id of the company.
     * @param maxPrice  - The price's upper limit.
     * @return - A list of Coupon objects.
     * @throws SQLException - Incorrect sql command.
     */
    public List<Coupon> getCompanyCouponsByMaxPrice(int companyID, double maxPrice) throws SQLException {
        return couponsDAO.getCompanyCouponsByMaxPrice(companyID, maxPrice);
    }

    /**
     * Receive a Company object from the data base(by id).
     *
     * @param companyID - the id of the company.
     * @throws SQLException       - Incorrect sql command.
     * @throws UserErrorException - There is no company with this id.
     */
    public void getCompanyDetails(int companyID) throws SQLException, UserErrorException {
        companiesDAO.getOneCompany(companyID);
    }
}

